/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shippingStore;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import shippingstore.PackageOrder;
import shippingstore.ShippingStore;
import java.util.ArrayList;
import org.junit.Ignore;

/**
 *
 * @author Daniel Ortiz (deo15)
 */
public class ShippingStoreTest {
    public static ShippingStore ss = null;
    ArrayList<PackageOrder> packageOrderList = null;
    public ShippingStoreTest() {
        File dataFile = new File("PackageOrderDB.txt");
        System.out.println("Testing if DataFile was created.");
        assertTrue(dataFile.exists());
    }
    
    @Before
    public void setUp() throws Exception {
        ss = new ShippingStore();
        ss.addOrder("ABC12", "Letter", "n/a", "Ground", "1.00", "6");
        System.out.println("Set Up Class.");
    }
    
    @After
    public void tearDown() {
        ss = null;
        System.out.println("Cleared Class");
    }

    /**
     * Test of getDataFile method, of class ShippingStore.
     */
    @Test
    public void testGetDataFile() throws Exception {
        System.out.println("getDataFile");
        ShippingStore instance = new ShippingStore();
        File expResult = null;
        File result = instance.getDataFile();
        assertNotEquals(expResult, result);
    }

    /**
     * Test of showPackageOrders method, of class ShippingStore.
     */
    @Test
    public void testShowPackageOrders() throws Exception {
        System.out.println("showPackageOrders");
        OutputStream os = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(os);
        System.setOut(ps);
        String separator = System.getProperty("line.separator");
        assertFalse(os.toString().contains(" -------------------------------------------------------------------------- "
         + separator + "| Tracking # | Type    | Specification | Class       | Weight(oz) | Volume |" + separator + 
                " -------------------------------------------------------------------------- "));
    }

    /**
     * Test of showPackageOrdersRange method, of class ShippingStore.
     */
    @Test
    public void testShowPackageOrdersRange() throws Exception {
        System.out.println("showPackageOrdersRange");
        String trackingnumber = "AAAAA", type = "Letter", 
                specification = "Books", mailingclass = "Ground", 
                weight = "2.0", volume = "1.0";
        ss.addOrder(trackingnumber, type, specification, mailingclass, weight, volume);
        trackingnumber = "BBBBB"; type = "Letter"; specification = "Books"; 
        mailingclass = "Ground"; weight = "2.0"; volume = "1.0";
        
        ss.addOrder(trackingnumber, type, specification, mailingclass, weight, volume);
        trackingnumber = "CCCCC"; type = "Letter"; specification = "Books"; 
        mailingclass = "Ground"; weight = "3.0"; volume = "1.0";
        
        ss.addOrder(trackingnumber, type, specification, mailingclass, weight, volume);
        trackingnumber = "DDDDD"; type = "Letter"; specification = "Books"; 
        mailingclass = "Ground"; weight = "4.0"; volume = "1.0";
        
        ss.addOrder(trackingnumber, type, specification, mailingclass, weight, volume);
        float low = 0.0F;
        float high = 1.0F;
        
        OutputStream os = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(os);
        System.setOut(ps);
        
        ss.showPackageOrdersRange(low, high);
        assertTrue(os.toString().contains("ABC12"));
        
        low = 1.0F;
        high = 2.0F;
        ss.showPackageOrdersRange(low, high);
        assertFalse(os.toString().contains("AAAAA"));
        
        low = 2.0F;
        high = 3.0F;
        ss.showPackageOrdersRange(low, high);
        assertFalse(os.toString().contains("BBBBB"));
        
        low = 3.0F;
        high = 4.0F;
        ss.showPackageOrdersRange(low, high);
        assertFalse(os.toString().contains("CCCCC"));
        
        low = 4.0F;
        high = 5.0F;
        ss.showPackageOrdersRange(low, high);
        assertFalse(os.toString().contains("DDDDD"));
    }

    /**
     * Test of findPackageOrder method, of class ShippingStore.
     */
    @Test
    public void testFindPackageOrder() throws Exception {
        System.out.println("findPackageOrder");
        String trackingNumber = "ABC12";
        int expResult = 0;
        int result = ss.findPackageOrder(trackingNumber);
        assertEquals(expResult, result);
        trackingNumber = "ABC";
        expResult = -1;
        result = ss.findPackageOrder(trackingNumber);
        assertEquals(expResult, result);
    }

    /**
     * Test of searchPackageOrder method, of class ShippingStore.
     */
    @Test
    public void testSearchPackageOrder() throws Exception {
        System.out.println("searchPackageOrder");
        String trackingNumber = "ABC12";
        ss.searchPackageOrder(trackingNumber);
//        assertEquals()
    }

    /**
     * Test of addOrder method, of class ShippingStore.
     */
    @Test
    public void testAddOrder() throws Exception {
        System.out.println("addOrder");
        String trackingnumber = "123AB";
        String type = "Letter";
        String specification = "n/a";
        String mailingclass = "First";
        String weight = "2.10";
        String volume = "7";
        ss.addOrder(trackingnumber, type, specification, mailingclass, weight, volume);
        int result = ss.findPackageOrder(trackingnumber);
        int unExpectedResult = 0;
        // TEST SHOULD NOT FIND MY TRACKING NUMBER. -1 is expected!
        assertNotEquals(result,unExpectedResult);
        
    }

    /**
     * Test of removeOrder method, of class ShippingStore.
     */
    @Test
    public void testRemoveOrder() throws Exception {
        System.out.println("removeOrder");
        String trackingNum = "ABC12";
        ss.removeOrder(trackingNum);
        int expected = -1;
        int result = ss.findPackageOrder(trackingNum);
        assertEquals(expected,result);
    }

    /**
     * Test of getPackageOrder method, of class ShippingStore.
     */
    @Test
    public void testGetPackageOrder() throws Exception {
        System.out.println("getPackageOrder");
        int i = -1;
        PackageOrder expResult = null;
        PackageOrder result = ss.getPackageOrder(-1);
        assertEquals(expResult, result);
        result = ss.getPackageOrder(0);
        String expResString = "ABC12"; 
        OutputStream os = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(os);
        System.setOut(ps);
        assertFalse(os.toString().contains(expResString));
    }

    /**
     * Test of read method, of class ShippingStore.
     */
    @Ignore
    @Test
    public void testRead() throws Exception {
        System.out.println("read");
        Reader dataReader = null;
        ShippingStore instance = new ShippingStore();
        instance.read(dataReader);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of flush method, of class ShippingStore.
     */
    @Ignore
    @Test
    public void testFlush() throws Exception {
        System.out.println("flush");
        Writer dataWriter = null;
        ShippingStore instance = new ShippingStore();
        instance.flush(dataWriter);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
