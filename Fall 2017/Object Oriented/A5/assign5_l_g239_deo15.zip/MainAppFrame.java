/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shippingstore;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
import java.util.logging.*;
import java.util.*;

/**
 *
 * MainAppFrame class contains all GUI components
 */
public class MainAppFrame {
    static private ShippingStore ss;
    final static Logger logger = Logger.getLogger("myLogger");
    /**
     * FileHandler adds logging into mylog.txt
     * @return new mylog.txt file
     */
    private static final FileHandler initFh(){
        FileHandler fh = null;
        try{
            fh = new FileHandler("mylog.txt");
            fh.setFormatter(new SimpleFormatter());
        }catch(IOException ex){
            Logger.getLogger(MainAppFrame.class.getName()).log(Level.SEVERE,null,ex);
        }catch(SecurityException ex){
            Logger.getLogger(MainAppFrame.class.getName()).log(Level.SEVERE,null,ex);
        }
        return fh;
    }
    /**
     * showGui method creates all components of ShippingStore GUI
     * @throws BadInputException 
     */
    public static void showGui() throws BadInputException{
        
        ss = new ShippingStore();
        JFrame frame1 = new JFrame("Shipping Store");
        frame1.setPreferredSize(new Dimension(400,600));
        frame1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        logger.log(Level.INFO, "Creating menu");
        JRadioButton showAllRButton = new JRadioButton("1) Show all existing packages in the database.");
        JRadioButton addPRButton = new JRadioButton("2) Add a new package to the database.");
        JRadioButton deletePRButton = new JRadioButton("3) Delete a package from a database (given its tracking number).");
        JRadioButton searchPRButton = new JRadioButton("4) Search for a package (given its tracking number).");
        JRadioButton showAllURButton = new JRadioButton("5) Show list of users.");
        JRadioButton addNewURButton = new JRadioButton("6) Add a new user to the database.");
        JRadioButton updateURButton = new JRadioButton("7) Update user info (given their id).");
        JRadioButton deliverPRButton = new JRadioButton("8) Deliver a package.");
        JRadioButton showAllTRButton = new JRadioButton("9) Show a list of transactions.");
       
        ButtonGroup group = new ButtonGroup();
        group.add(showAllRButton);
        group.add(addPRButton);
        group.add(deletePRButton);
        group.add(searchPRButton);
        group.add(showAllURButton);
        group.add(addNewURButton);
        group.add(updateURButton);
        group.add(deliverPRButton);
        group.add(showAllTRButton);
        
        JButton exitButton = new JButton("Save");
        JButton goButton = new JButton("GO");
        
        JPanel radioPanel = new JPanel();
        radioPanel.setLayout(new GridLayout(0,1));
        
        frame1.setLayout(new BorderLayout()); 
        frame1.add(radioPanel,BorderLayout.WEST);
        
        frame1.add(new JLabel("Menu"), BorderLayout.NORTH);
        radioPanel.add(showAllRButton);
        radioPanel.add(addPRButton);
        radioPanel.add(deletePRButton);
        radioPanel.add(searchPRButton);
        radioPanel.add(showAllURButton);
        radioPanel.add(addNewURButton);
        radioPanel.add(updateURButton);
        radioPanel.add(deliverPRButton);
        radioPanel.add(showAllTRButton);
        
        JPanel panelB = new JPanel();
        panelB.setLayout(new FlowLayout());
        frame1.add(panelB,BorderLayout.SOUTH);
        panelB.add(exitButton);
        panelB.add(goButton);
        frame1.pack(); frame1.setVisible(true);
        
        exitButton.addActionListener((ActionEvent e) ->{
            
            ss.writeDatabase();
            logger.log(Level.INFO, "Writing database to serializable object");
            
        });
        
        goButton.addActionListener((ActionEvent e) -> {
            
            if(showAllRButton.isSelected()){
                logger.log(Level.INFO, "Outputting packages in database");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame called SHOW ALL PACKAGES
                JFrame frame2 = new JFrame("Show all packages.");
                frame2.setPreferredSize(new Dimension(1000,1000));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new BorderLayout());
                
                String[] columnNames = {"PACKAGE TYPE",
                                        "TRACKING #",
                                        "SPECIFICATION",
                                        "MAILING CLASS",
                                        "DIMENSION / CONTENT / DIAMETER / WIDTH",
                                        "VOLUME / LOADWEIGHT / MATERIAL / HEIGHT"};
                String[][] pList = new String[ss.packageList.size()][6];
                for(Package p: ss.packageList){
                    if(p instanceof Box){
                        pList[ss.packageList.indexOf(p)][0] = "BOX";
                        pList[ss.packageList.indexOf(p)][1] = ((Box) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Box) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Box) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = "" + ((Box) p).getDimension();
                        pList[ss.packageList.indexOf(p)][5] = "" +((Box) p).getVolume();
                    }
                    if(p instanceof Crate){
                        pList[ss.packageList.indexOf(p)][0] = "CRATE";
                        pList[ss.packageList.indexOf(p)][1] = ((Crate) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Crate) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Crate) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = ((Crate) p).getContent();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Crate) p).getLoadWeight();
                    }
                    if(p instanceof Drum){
                        pList[ss.packageList.indexOf(p)][0] = "DRUM";
                        pList[ss.packageList.indexOf(p)][1] = ((Drum) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Drum) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Drum) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = ((Drum) p).getMaterial();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Drum) p).getDiameter();
                    }
                    if(p instanceof Envelope){
                        pList[ss.packageList.indexOf(p)][0] = "ENVELOPE";
                        pList[ss.packageList.indexOf(p)][1] = ((Envelope) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Envelope) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Envelope) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = "" + ((Envelope) p).getHeight();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Envelope) p).getWidth();
                    }
                }
                // adding panel for return button
                JTable table = new JTable(pList,columnNames);
                JScrollPane scrollPane = new JScrollPane(table);
                
                frame2.add(scrollPane, BorderLayout.CENTER);
                JPanel pan = new JPanel();
                pan.setLayout(new FlowLayout(FlowLayout.LEFT));
                JButton back = new JButton("Back to Menu");
                pan.add(back);
                // adding panel to frame2 Show all packages.
                frame2.add(pan,BorderLayout.SOUTH);
                frame2.setVisible(true); frame2.pack();
                // lambda expression for actionlistener of return button
                back.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(addPRButton.isSelected()){

                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Adding package");
                frame2.setPreferredSize(new Dimension(400,300));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                //creating all JPanels, JComboBoxes, JTextFields, and JButtons and initializing all of them
                JPanel packPanel, buttonPanel, allPackOpsPanel, otherOpsPanel; //initialize panels
                packPanel = new JPanel();
                packPanel.setLayout(new FlowLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                allPackOpsPanel = new JPanel();
                allPackOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel = new JPanel();
                otherOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel.setVisible(false); //defaulted to false, turned on when specific fields added to it
                JComboBox<String> packCB, specCB, mailCB, materialCB;
                String[] packs = new String[] {"Choose Package Type","Envelope", "Box", "Crate", "Drum"};
                packCB = new JComboBox<>(packs);
                String[] sp = new String[] {"Choose Specification" ,"Fragile", "Books", "Catalogs", "Do-not-bend", "N/A"};
                specCB = new JComboBox<>(sp);
                String[] mc = new String[] {"Choose Mail Class","First-Class", "Priority", "Retail", "Ground", "Metro."};
                mailCB = new JComboBox<>(mc);
                String[] ops = new String[] {"Choose Material","Plastic", "Fiber"};
                materialCB = new JComboBox(ops);
                JTextField trackNumTF, heightTF, widthTF, largeDimTF, volTF, weightTF, contentTF, diamTF;
                trackNumTF = new JTextField(5);
                heightTF = new JTextField(6);
                widthTF = new JTextField(6);
                largeDimTF = new JTextField(6);
                volTF = new JTextField(6);
                weightTF = new JTextField(6);
                contentTF = new JTextField(15);
                diamTF = new JTextField(6);
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                packPanel.add(packCB, coord);
                frame2.add(packPanel);

                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 3;
                frame2.add(buttonPanel,coord);
                packCB.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Inputting info for new package");
                        
                        String packChoice = (String) packCB.getItemAt(packCB.getSelectedIndex());
                        JLabel TNlabel = new JLabel(" Tracking Number: ");
                        coord.fill = GridBagConstraints.HORIZONTAL;
                        coord.weightx = 0.5; coord.weighty = 1; coord.gridx = 1; coord.gridy = 0;
                        allPackOpsPanel.add(TNlabel, coord);
                        coord.gridx = 2; //change for trackNumTF
                        allPackOpsPanel.add(trackNumTF, coord);
                        JLabel Slabel = new JLabel(" Specification: ");
                        coord.gridx = 1; coord.gridy = 1;
                        allPackOpsPanel.add(Slabel, coord);
                        coord.gridx = 2; //change for specCB
                        allPackOpsPanel.add(specCB, coord);
                        JLabel MClabel = new JLabel(" Mailing Class: ");
                        coord.gridx = 1; coord.gridy = 2;
                        allPackOpsPanel.add(MClabel, coord);
                        coord.gridx = 2; //change for mailCB
                        allPackOpsPanel.add(mailCB, coord);
                        allPackOpsPanel.setVisible(true);
                        coord.gridx = 0; coord.gridy = 1;
                        frame2.add(allPackOpsPanel, coord);

                        coord.gridx = 0; coord.gridy = 2; //change for otherOpsPanel
                        frame2.add(otherOpsPanel,coord);
                        
                        if(packChoice.equals("Envelope")){
                            otherOpsPanel.setVisible(true);
                            JLabel height = new JLabel(" Height (int--inches): ");
                            coord.gridx = 1; coord.gridy = 0;
                            otherOpsPanel.add(height,coord);
                            coord.gridx = 2; //change for heightTF
                            otherOpsPanel.add(heightTF, coord);
                            JLabel width = new JLabel(" Width (int--inches): ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(width,coord);
                            coord.gridx = 2; //change for widthTF
                            otherOpsPanel.add(widthTF, coord);
                            
                        }else if(packChoice.equals("Box")){
                            otherOpsPanel.setVisible(true);
                            JLabel largestDim = new JLabel(" Largest Dimension (int--inches): ");
                            coord.gridx = 1; coord.gridy = 0;
                            otherOpsPanel.add(largestDim,coord);
                            coord.gridx = 2; //change for largeDimTF
                            otherOpsPanel.add(largeDimTF, coord);
                            JLabel vol = new JLabel(" Volume (int--inch^3): ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(vol,coord);
                            coord.gridx = 2; //change for volTF
                            otherOpsPanel.add(volTF, coord);
                        }else if(packChoice.equals("Crate")){
                            otherOpsPanel.setVisible(true);
                            JLabel weight = new JLabel(" Maximum Load Weight (float--lb): ");
                            coord.gridx = 1; coord.gridy = 0;
                            otherOpsPanel.add(weight,coord);
                            coord.gridx = 2; //change for weightTF
                            otherOpsPanel.add(weightTF, coord);
                            JLabel content = new JLabel(" Content (string): ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(content,coord);
                            coord.gridx = 2; ////change for contentTF
                            otherOpsPanel.add(contentTF, coord);
                        }else if(packChoice.equals("Drum")){
                            otherOpsPanel.setVisible(true);
                            JLabel material = new JLabel(" Material: ");
                            coord.gridx = 2; coord.gridy = 0; //change for materialCB
                            otherOpsPanel.add(materialCB,coord);
                            JLabel diameter = new JLabel(" Diameter (float): ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(diameter,coord);
                            coord.gridx = 2; //change for diamTF
                            otherOpsPanel.add(diamTF, coord);
                        }
                        frame2.pack();
                        
                    }
                });
                
                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Adding new package");
                        String specChoice = (String) specCB.getItemAt(specCB.getSelectedIndex());
                        String mcChoice = (String) mailCB.getItemAt(mailCB.getSelectedIndex());
                        String trackNumChoice = (String) trackNumTF.getText();
                        String packChoice = (String) packCB.getItemAt(packCB.getSelectedIndex());
                        if((trackNumChoice.length() > 5) || (trackNumChoice.length() == 0)){
                            JOptionPane.showMessageDialog(null, "Tracking number should not be more that 5 characters long.", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                        else if(ss.packageExists(trackNumChoice)){
                            JOptionPane.showMessageDialog(null, "Package with given tracking number exists in database", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                        else if(specChoice.equals("Choose Specification") || mcChoice.equals("Choose Mail Class")){
                            JOptionPane.showMessageDialog(null, "Must select a specification and mail class", "Warning", JOptionPane.WARNING_MESSAGE);

                        }
                        else if(packChoice.equals("Envelope")){
                            try{
                                int height = Integer.parseInt(heightTF.getText());
                                int width = Integer.parseInt(widthTF.getText());
                                if((height > 0) && (width > 0)){
                                    ss.addEnvelope(trackNumChoice, specChoice, mcChoice, height, width);
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Package added successfully");                                            
                                }else{
                                    JOptionPane.showMessageDialog(null, "Height and Width should be greater than 0", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                        
                            }catch(NumberFormatException er){
                                logger.log(Level.WARNING, "Height and width for package NOT integers");
                                    JOptionPane.showMessageDialog(null, "Height and Width must be integers", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                        }else if(packChoice.equals("Box")){
                            try{
                                int ld = Integer.parseInt(largeDimTF.getText());
                                int v = Integer.parseInt(volTF.getText());
                                if((ld > 0) && (v > 0)){
                                    ss.addBox(trackNumChoice, specChoice, mcChoice, ld, v);
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Package added successfully");                                            
                                }else{
                                    JOptionPane.showMessageDialog(null, "Largest Dimension and Volume should be greater than 0", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                        
                            }catch(NumberFormatException er){
                                logger.log(Level.WARNING, "Largest Dimension and Volume for package NOT integers");
                                JOptionPane.showMessageDialog(null, "Largest Dimension and Volume must be integers", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                                    
                        }else if(packChoice.equals("Crate")){
                            try{
                                float weight = Float.parseFloat(weightTF.getText());
                                String content = contentTF.getText();
                                if((weight > 0)){
                                    ss.addCrate(trackNumChoice, specChoice, mcChoice, weight, content);
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Package added successfully");                                            
                                }else{
                                    JOptionPane.showMessageDialog(null, "Weight should be greater than 0", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                        
                            }catch(NumberFormatException er){
                                logger.log(Level.WARNING, "Weight for package NOT float");
                                JOptionPane.showMessageDialog(null, "Weight must be float", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                                    
                        }else if(packChoice.equals("Drum")){
                            try{
                                float diam = Float.parseFloat(diamTF.getText());
                                String material = (String) materialCB.getItemAt(materialCB.getSelectedIndex());
                                if((diam > 0)){
                                    ss.addDrum(trackNumChoice, specChoice, mcChoice, material, diam);
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Package added successfully");                                            
                                }else if(material.equals("Choose Material")){
                                    JOptionPane.showMessageDialog(null, "Must choose material.", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                else{
                                    JOptionPane.showMessageDialog(null, "Weight should be greater than 0", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                        
                            }catch(NumberFormatException er){
                                logger.log(Level.WARNING, "Diameter for package NOT float");
                                JOptionPane.showMessageDialog(null, "Diameter must be float", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                        }
                    }
                });
               
                frame2.setVisible(true); frame2.pack();                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(deletePRButton.isSelected()){
                logger.log(Level.INFO, "Entering tracking number for package to delete");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Deleting package");
                frame2.setPreferredSize(new Dimension(400,300));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                coord.fill = GridBagConstraints.HORIZONTAL;
                JPanel tnPanel, buttonPanel;
                tnPanel = new JPanel();
                tnPanel.setLayout(new GridBagLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                JLabel TNlabel = new JLabel("Enter Tracking Number: ");
                JTextField trackNumTF = new JTextField(5);
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                tnPanel.add(TNlabel, coord);
                coord.gridx = 1;
                tnPanel.add(trackNumTF, coord);
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                frame2.add(tnPanel,coord);

                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 3;
                frame2.add(buttonPanel,coord);
                frame2.setVisible(true); frame2.pack();

                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Deleting package");
                        String trackNum = (String)trackNumTF.getText();
                        if(ss.deletePackage(trackNum)){
                            JOptionPane.showMessageDialog(null, "Package deleted successfully"); 
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "Package with given tracking number not found in the database.", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                });
                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(searchPRButton.isSelected()){
                logger.log(Level.INFO, "Searching package with tracking number");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Search package");
                frame2.setPreferredSize(new Dimension(600,600));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                coord.fill = GridBagConstraints.HORIZONTAL;
                JPanel tnPanel, buttonPanel;
                tnPanel = new JPanel();
                tnPanel.setLayout(new GridBagLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                JLabel TNlabel = new JLabel("Enter Tracking Number to Search: ");
                JTextField trackNumTF = new JTextField(5);
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                tnPanel.add(TNlabel, coord);
                coord.gridx = 1;
                tnPanel.add(trackNumTF, coord);
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                frame2.add(tnPanel,coord);

                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 3;
                frame2.add(buttonPanel,coord);
                frame2.setVisible(true); frame2.pack();

                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Showing package searched");
                        String trackNum = (String)trackNumTF.getText();
                        if(ss.packageExists(trackNum)){
                             String[] columnNames = {"PACKAGE TYPE",
                                        "TRACKING #",
                                        "SPECIFICATION",
                                        "MAILING CLASS",
                                        "DIMENSION / CONTENT / DIAMETER / WIDTH",
                                        "VOLUME / LOADWEIGHT / MATERIAL / HEIGHT"};
                            String[][] pList = new String[ss.packageList.size()][6];
                            Package p = ss.findPackage(trackNum);
                        if(p instanceof Box){
                        pList[ss.packageList.indexOf(p)][0] = "BOX";
                        pList[ss.packageList.indexOf(p)][1] = ((Box) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Box) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Box) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = "" + ((Box) p).getDimension();
                        pList[ss.packageList.indexOf(p)][5] = "" +((Box) p).getVolume();
                    }
                    if(p instanceof Crate){
                        pList[ss.packageList.indexOf(p)][0] = "CRATE";
                        pList[ss.packageList.indexOf(p)][1] = ((Crate) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Crate) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Crate) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = ((Crate) p).getContent();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Crate) p).getLoadWeight();
                    }
                    if(p instanceof Drum){
                        pList[ss.packageList.indexOf(p)][0] = "DRUM";
                        pList[ss.packageList.indexOf(p)][1] = ((Drum) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Drum) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Drum) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = ((Drum) p).getMaterial();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Drum) p).getDiameter();
                    }
                    if(p instanceof Envelope){
                        pList[ss.packageList.indexOf(p)][0] = "ENVELOPE";
                        pList[ss.packageList.indexOf(p)][1] = ((Envelope) p).ptn;
                        pList[ss.packageList.indexOf(p)][2] = ((Envelope) p).specification;
                        pList[ss.packageList.indexOf(p)][3] = ((Envelope) p).mailingClass;
                        pList[ss.packageList.indexOf(p)][4] = "" + ((Envelope) p).getHeight();
                        pList[ss.packageList.indexOf(p)][5] = "" + ((Envelope) p).getWidth();
                    }
                        JTable table = new JTable(pList,columnNames);
                        JScrollPane scrollPane = new JScrollPane(table);
                        coord.gridx = 0; coord.gridy = 1;
                        frame2.add(scrollPane,coord);
                        frame2.pack();
                        //frame2.add(scrollPane, BorderLayout.CENTER);
                        }
                        else{
                            JOptionPane.showMessageDialog(null, "Package with PTN " + trackNum + " not found in the database", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                    }
                });
                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(showAllURButton.isSelected()){
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame called SHOW ALL PACKAGES
                JFrame frame2 = new JFrame("Show all Users.");
                frame2.setPreferredSize(new Dimension(1000,1000));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new BorderLayout());
                
                String[] columnNames = {"USER TYPE",
                                        "USER ID",
                                        "FIRST NAME",
                                        "LAST NAME",
                                        "PHONE NUMBER",
                                        "ADDRESS",
                                        "S.S. NUMBER",
                                        "BANK ACC NUMBER",
                                        "MONTHLY SALARY"};
                String[][] uList = new String[ss.users.size()][9];
                for(User u: ss.users){
                    if(u instanceof Customer){
                        uList[ss.users.indexOf(u)][0] = "CUSTOMER";
                        uList[ss.users.indexOf(u)][1] = "" + u.getId();
                        uList[ss.users.indexOf(u)][2] = u.getFirstName();
                        uList[ss.users.indexOf(u)][3] = u.getLastName();
                        uList[ss.users.indexOf(u)][4] = ((Customer) u).getPhoneNumber();
                        uList[ss.users.indexOf(u)][5] = ((Customer) u).getAddress();
                        uList[ss.users.indexOf(u)][6] = "N/A"; //S.S. NUMBER
                        uList[ss.users.indexOf(u)][7] = "N/A"; //BANK ACC NUMBER
                        uList[ss.users.indexOf(u)][8] = "N/A"; //MONTHLY SALARY
                        
                    }
                    if(u instanceof Employee){
                        uList[ss.users.indexOf(u)][0] = "EMPLOYEE";
                        uList[ss.users.indexOf(u)][1] = "" + u.getId();
                        uList[ss.users.indexOf(u)][2] = u.getFirstName();
                        uList[ss.users.indexOf(u)][3] = u.getLastName();
                        uList[ss.users.indexOf(u)][4] = "N/A"; //phone num
                        uList[ss.users.indexOf(u)][5] = "N/A"; //address
                        uList[ss.users.indexOf(u)][6] = "" + ((Employee) u).getSocialSecurityNumber(); 
                        uList[ss.users.indexOf(u)][7] = "" + ((Employee) u).getBankAccountNumber();
                        uList[ss.users.indexOf(u)][8] = "" + ((Employee) u).getSocialSecurityNumber();
                        
                    }
                }
                // adding panel for return button
                JTable table = new JTable(uList,columnNames);
                JScrollPane scrollPane = new JScrollPane(table);
                
                frame2.add(scrollPane, BorderLayout.CENTER);
                JPanel pan = new JPanel();
                pan.setLayout(new FlowLayout(FlowLayout.LEFT));
                JButton back = new JButton("Back to Menu");
                pan.add(back);
                // adding panel to frame2 Show all packages.
                frame2.add(pan,BorderLayout.SOUTH);
                frame2.setVisible(true); frame2.pack();
                // lambda expression for actionlistener of return button
                back.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(addNewURButton.isSelected()){
                logger.log(Level.INFO, "Inputting info for new user");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Add New User.");
                frame2.setPreferredSize(new Dimension(400,300));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                //creating all JPanels, JComboBoxes, JTextFields, and JButtons and initializing all of them
                JPanel packPanel, buttonPanel, allPackOpsPanel, otherOpsPanel; //initialize panels
                packPanel = new JPanel();
                packPanel.setLayout(new FlowLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                allPackOpsPanel = new JPanel();
                allPackOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel = new JPanel();
                otherOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel.setVisible(false); //defaulted to false, turned on when specific fields added to it
                JComboBox<String> userCB;
                String[] packs = new String[] {"Choose User Type","Customer", "Employee"};
                userCB = new JComboBox<>(packs);
                JTextField firstNameTF, lastNameTF, phoneNumTF, addressTF, monthlySalTF, SSNTF, bankAccTF;
                firstNameTF = new JTextField(10);
                lastNameTF = new JTextField(10);
                phoneNumTF = new JTextField(7);
                addressTF = new JTextField(20);
                monthlySalTF = new JTextField(9);
                SSNTF = new JTextField(9);
                bankAccTF = new JTextField(15);
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                packPanel.add(userCB, coord);
                frame2.add(packPanel);

                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 3;
                frame2.add(buttonPanel,coord);
                userCB.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Inputting info for new user");
                        
                        String packChoice = (String) userCB.getItemAt(userCB.getSelectedIndex());
                        
                        JLabel fNameLabel = new JLabel(" First Name: ");
                        coord.fill = GridBagConstraints.HORIZONTAL;
                        coord.weightx = 0.5; coord.weighty = 1; coord.gridx = 1; coord.gridy = 0;
                        allPackOpsPanel.add(fNameLabel, coord);
                        coord.gridx = 2; //change for firstNameTF
                        allPackOpsPanel.add(firstNameTF, coord);
                        
                        JLabel lastNameLabel = new JLabel(" Last Name: ");
                        coord.gridx = 1; coord.gridy = 1;
                        allPackOpsPanel.add(lastNameLabel, coord);
                        coord.gridx = 2; //change for lastNameTF
                        allPackOpsPanel.add(lastNameTF, coord);
                        
                        coord.gridx = 0; coord.gridy = 2; //change for otherOpsPanel
                        frame2.add(otherOpsPanel,coord);
                        
                        if(packChoice.equals("Customer")){
                            otherOpsPanel.setVisible(true);
                            
                            JLabel firstLabel = new JLabel(" First Name: ");
                            coord.gridx = 1; coord.gridy = 0;
                            otherOpsPanel.add(firstLabel,coord);
                            coord.gridx = 2; //change for phoneNumTF
                            otherOpsPanel.add(firstNameTF, coord);
                            
                            JLabel lastLabel = new JLabel(" Last Name: ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(lastLabel,coord);
                            coord.gridx = 2; //change for phoneNumTF
                            otherOpsPanel.add(lastNameTF, coord);
                            
                            JLabel phoneNumLabel = new JLabel(" Phone Number: ");
                            coord.gridx = 1; coord.gridy = 2;
                            otherOpsPanel.add(phoneNumLabel,coord);
                            coord.gridx = 2; //change for phoneNumTF
                            otherOpsPanel.add(phoneNumTF, coord);
                            
                            JLabel addressLabel = new JLabel(" Address: ");
                            coord.gridx = 1; coord.gridy = 3;
                            otherOpsPanel.add(addressLabel,coord);
                            coord.gridx = 2; //change for addressTF
                            otherOpsPanel.add(addressTF, coord);
                            
                        }else if(packChoice.equals("Employee")){
                            otherOpsPanel.setVisible(true);
                            
                            JLabel firstLabel = new JLabel(" First Name: ");
                            coord.gridx = 1; coord.gridy = 0;
                            otherOpsPanel.add(firstLabel,coord);
                            coord.gridx = 2; //change for phoneNumTF
                            otherOpsPanel.add(firstNameTF, coord);
                            
                            JLabel lastLabel = new JLabel(" Last Name: ");
                            coord.gridx = 1; coord.gridy = 1;
                            otherOpsPanel.add(lastLabel,coord);
                            coord.gridx = 2; //change for phoneNumTF
                            otherOpsPanel.add(lastNameTF, coord);
                            
                            JLabel monthlySalLabel = new JLabel(" Monthly Salary: ");
                            coord.gridx = 1; coord.gridy = 2;
                            otherOpsPanel.add(monthlySalLabel,coord);
                            coord.gridx = 2; //change for monthlySalTF
                            otherOpsPanel.add(monthlySalTF, coord);
                            
                            JLabel SSNLabel = new JLabel(" SSN: ");
                            coord.gridx = 1; coord.gridy = 3;
                            otherOpsPanel.add(SSNLabel,coord);
                            coord.gridx = 2; //change for SSNTF
                            otherOpsPanel.add(SSNTF, coord);
                            
                            JLabel bankAccLabel = new JLabel(" Bank Account Number: ");
                            coord.gridx = 1; coord.gridy = 4;
                            otherOpsPanel.add(bankAccLabel,coord);
                            coord.gridx = 2; //change for bankAccTF
                            otherOpsPanel.add(bankAccTF, coord);
                        }
                        frame2.pack();   
                    }
                });
                
                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        logger.log(Level.INFO, "Adding new user");
//                        String specChoice = (String) specCB.getItemAt(specCB.getSelectedIndex());
//                        String mcChoice = (String) mailCB.getItemAt(mailCB.getSelectedIndex());
                        String firstName = (String) firstNameTF.getText();
                        String lastName = (String) lastNameTF.getText();
                        String address = (String) addressTF.getText();
                        String phoneNum = (String) phoneNumTF.getText();
                        String userChoice = (String) userCB.getItemAt(userCB.getSelectedIndex());
                        if(userChoice.equals("Employee")){
                            try{
                                float monthly = Float.parseFloat(monthlySalTF.getText());
                                int acc = Integer.parseInt(bankAccTF.getText());
                                int ssn = Integer.parseInt(SSNTF.getText());
                                if((monthly > 0.0f) && (String.valueOf(ssn).length() == 9) && (ssn > 10000000 || ssn < 999999999) && (acc > 0)){
                                    ss.addEmployee(firstName, lastName, ssn, monthly, acc);
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Employee added successfully");                                            
                                }else{
                                    JOptionPane.showMessageDialog(null, "Monthly Salary must be > 0.0, SSN must be 9 digits & a correct 9 digit integer,\n"
                                                                        + " Bank account must be > 0.", "Warning", JOptionPane.WARNING_MESSAGE);
                                }
                                        
                            }catch(NumberFormatException er){
                                logger.log(Level.WARNING, "Monthly, Bank Account, or SSN are NOT integers");
                                    JOptionPane.showMessageDialog(null, "Monthly, Bank Account, or SSN must be integers", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                        }
                        else if(userChoice.equals("Customer")){
                            ss.addCustomer(firstName, lastName, phoneNum, address); 
                            frame2.setVisible(false);frame1.setVisible(true);
                            JOptionPane.showMessageDialog(null, "Customer added successfully");
                        }
                    }
                });
               
                frame2.setVisible(true); frame2.pack();                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(updateURButton.isSelected()){
                logger.log(Level.INFO, "Inputting info to update user");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Update User.");
                frame2.setPreferredSize(new Dimension(400,300));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                //creating all JPanels, JComboBoxes, JTextFields, and JButtons and initializing all of them
                JPanel packPanel, buttonPanel, allPackOpsPanel, otherOpsPanel; //initialize panels
                packPanel = new JPanel();
                packPanel.setLayout(new FlowLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                allPackOpsPanel = new JPanel();
                allPackOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel = new JPanel();
                otherOpsPanel.setLayout(new GridBagLayout());
                otherOpsPanel.setVisible(false); //defaulted to false, turned on when specific fields added to it
                
                JTextField userID, firstNameTF, lastNameTF, phoneNumTF, addressTF, monthlySalTF, SSNTF, bankAccTF;
                userID = new JTextField(10);
                firstNameTF = new JTextField(10);
                lastNameTF = new JTextField(10);
                phoneNumTF = new JTextField(7);
                addressTF = new JTextField(20);
                monthlySalTF = new JTextField(9);
                SSNTF = new JTextField(9);
                bankAccTF = new JTextField(15);
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                packPanel.add(userID, coord);
                frame2.add(packPanel);
                
                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 3;
                frame2.add(buttonPanel,coord);
                
                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int id = -1;
                        try{
                            id = Integer.parseInt(userID.getText());
                        
                        }catch(NumberFormatException er){
                            logger.log(Level.WARNING,"ID not an Integer");
                        }
                        if(!ss.userExists(id)){
                            logger.log(Level.WARNING, "UserID does not exist");
                            JOptionPane.showMessageDialog(null, "UserID does not exist", "Warning", JOptionPane.WARNING_MESSAGE);
                        }
                        else{
                            logger.log(Level.INFO, "Updating info for new user");
                            JLabel fNameLabel = new JLabel(" First Name: ");
                            coord.fill = GridBagConstraints.HORIZONTAL;
                            coord.weightx = 0.5; coord.weighty = 1; coord.gridx = 1; coord.gridy = 0;
                            allPackOpsPanel.add(fNameLabel, coord);
                            coord.gridx = 2; //change for firstNameTF
                            allPackOpsPanel.add(firstNameTF, coord);

                            JLabel lastNameLabel = new JLabel(" Last Name: ");
                            coord.gridx = 1; coord.gridy = 1;
                            allPackOpsPanel.add(lastNameLabel, coord);
                            coord.gridx = 2; //change for lastNameTF
                            allPackOpsPanel.add(lastNameTF, coord);

                            coord.gridx = 0; coord.gridy = 2; //change for otherOpsPanel
                            frame2.add(otherOpsPanel,coord);

                            if(ss.isCustomer(id)){
                                otherOpsPanel.setVisible(true);

                                JLabel firstLabel = new JLabel(" First Name: ");
                                coord.gridx = 1; coord.gridy = 0;
                                otherOpsPanel.add(firstLabel,coord);
                                coord.gridx = 2; //change for phoneNumTF
                                otherOpsPanel.add(firstNameTF, coord);

                                JLabel lastLabel = new JLabel(" Last Name: ");
                                coord.gridx = 1; coord.gridy = 1;
                                otherOpsPanel.add(lastLabel,coord);
                                coord.gridx = 2; //change for phoneNumTF
                                otherOpsPanel.add(lastNameTF, coord);

                                JLabel phoneNumLabel = new JLabel(" Phone Number: ");
                                coord.gridx = 1; coord.gridy = 2;
                                otherOpsPanel.add(phoneNumLabel,coord);
                                coord.gridx = 2; //change for phoneNumTF
                                otherOpsPanel.add(phoneNumTF, coord);

                                JLabel addressLabel = new JLabel(" Address: ");
                                coord.gridx = 1; coord.gridy = 3;
                                otherOpsPanel.add(addressLabel,coord);
                                coord.gridx = 2; //change for addressTF
                                otherOpsPanel.add(addressTF, coord);

                            }else if(ss.isEmployee(id)){
                                otherOpsPanel.setVisible(true);

                                JLabel firstLabel = new JLabel(" First Name: ");
                                coord.gridx = 1; coord.gridy = 0;
                                otherOpsPanel.add(firstLabel,coord);
                                coord.gridx = 2; //change for phoneNumTF
                                otherOpsPanel.add(firstNameTF, coord);

                                JLabel lastLabel = new JLabel(" Last Name: ");
                                coord.gridx = 1; coord.gridy = 1;
                                otherOpsPanel.add(lastLabel,coord);
                                coord.gridx = 2; //change for phoneNumTF
                                otherOpsPanel.add(lastNameTF, coord);

                                JLabel monthlySalLabel = new JLabel(" Monthly Salary: ");
                                coord.gridx = 1; coord.gridy = 2;
                                otherOpsPanel.add(monthlySalLabel,coord);
                                coord.gridx = 2; //change for monthlySalTF
                                otherOpsPanel.add(monthlySalTF, coord);

                                JLabel SSNLabel = new JLabel(" SSN: ");
                                coord.gridx = 1; coord.gridy = 3;
                                otherOpsPanel.add(SSNLabel,coord);
                                coord.gridx = 2; //change for SSNTF
                                otherOpsPanel.add(SSNTF, coord);

                                JLabel bankAccLabel = new JLabel(" Bank Account Number: ");
                                coord.gridx = 1; coord.gridy = 4;
                                otherOpsPanel.add(bankAccLabel,coord);
                                coord.gridx = 2; //change for bankAccTF
                                otherOpsPanel.add(bankAccTF, coord);
                            }
                            frame2.pack();   
                        }
                        final int uid = id;
                        enterButton.addActionListener(new ActionListener(){
                            public void actionPerformed(ActionEvent e){
                                String firstName = (String) firstNameTF.getText();
                                String lastName = (String) lastNameTF.getText();
                                String address = (String) addressTF.getText();
                                String phoneNum = (String) phoneNumTF.getText();
                               
                                if(ss.isEmployee(uid)){
                                    try{
                                        float monthly = Float.parseFloat(monthlySalTF.getText());
                                        int acc = Integer.parseInt(bankAccTF.getText());
                                        int ssn = Integer.parseInt(SSNTF.getText());
                                        if((monthly > 0.0f) && (String.valueOf(ssn).length() == 9) && (ssn > 10000000 || ssn < 999999999) && (acc > 0)){
                                            ss.updateEmployee(uid, firstName, lastName, ssn, monthly, acc);
                                            frame2.setVisible(false);frame1.setVisible(true);
                                            JOptionPane.showMessageDialog(null, "Employee added successfully");                                            
                                        }else{
                                            JOptionPane.showMessageDialog(null, "Monthly Salary must be > 0.0, SSN must be 9 digits & a correct 9 digit integer,\n"
                                                                                + " Bank account must be > 0.", "Warning", JOptionPane.WARNING_MESSAGE);
                                        }

                                        }catch(NumberFormatException er){
                                            logger.log(Level.WARNING, "Monthly, Bank Account, or SSN are NOT integers");
                                            JOptionPane.showMessageDialog(null, "Monthly, Bank Account, or SSN must be integers", "Warning", JOptionPane.WARNING_MESSAGE);
                                        }
                                }
                                else if(ss.isCustomer(uid)){
                                    ss.updateCustomer(uid,firstName, lastName, phoneNum, address); 
                                    frame2.setVisible(false);frame1.setVisible(true);
                                    JOptionPane.showMessageDialog(null, "Customer updated successfully");
                                }
                            }
                        });
                        
                    }
                });
               
                frame2.setVisible(true); frame2.pack();                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(deliverPRButton.isSelected()){
                logger.log(Level.INFO, "Inputting info for delivering package");
                Date currentDate = new Date(System.currentTimeMillis());
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame
                JFrame frame2 = new JFrame("Delivering package");
                frame2.setPreferredSize(new Dimension(400,300));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new GridBagLayout());
                GridBagConstraints coord = new GridBagConstraints();
                coord.fill = GridBagConstraints.HORIZONTAL;
                JPanel inputsPanel, buttonPanel;
                inputsPanel = new JPanel();
                inputsPanel.setLayout(new GridBagLayout());
                buttonPanel = new JPanel();
                buttonPanel.setLayout(new BorderLayout());
                JButton backButton, enterButton;
                backButton = new JButton("Back to Menu");
                enterButton = new JButton("ENTER");
                JLabel TNlabel, cIDLabel, emIDLabel, priceLabel;
                cIDLabel = new JLabel("Customer ID: ");
                emIDLabel = new JLabel("Employee ID: ");
                TNlabel = new JLabel("Tracking Number: ");
                priceLabel = new JLabel("Price (float): ");
                JTextField trackNumTF, cIDTF, emIDTF, priceTF;
                cIDTF = new JTextField(10);
                emIDTF = new JTextField(10);
                trackNumTF = new JTextField(5);;
                priceTF = new JTextField(6);
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                inputsPanel.add(cIDLabel, coord);
                coord.gridx = 1;
                inputsPanel.add(cIDTF, coord);
                coord.gridx = 0; coord.gridy = 1;
                inputsPanel.add(emIDLabel, coord);
                coord.gridx = 1;
                inputsPanel.add(emIDTF, coord);
                coord.gridx = 0; coord.gridy = 2;
                inputsPanel.add(TNlabel, coord);
                coord.gridx = 1;
                inputsPanel.add(trackNumTF, coord);
                coord.gridx = 0; coord.gridy = 3;
                inputsPanel.add(priceLabel, coord);
                coord.gridx = 1;
                inputsPanel.add(priceTF, coord);
                
                coord.gridx = 0; coord.gridy = 0; coord.weighty = 1;
                frame2.add(inputsPanel,coord);

                buttonPanel.add(backButton,BorderLayout.WEST);
                buttonPanel.add(enterButton, BorderLayout.EAST);
                // adding panel to frame2 Show all packages.
                coord.gridx = 0; coord.gridy = 4;
                frame2.add(buttonPanel,coord);
                frame2.setVisible(true); frame2.pack();

                enterButton.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        
                        try{
                            logger.log(Level.INFO, "Delivering package");
                            int customerID = Integer.parseInt(cIDTF.getText());
                            int employeeID = Integer.parseInt(emIDTF.getText());
                            String trackNum = (String)trackNumTF.getText();
                            Float price = Float.parseFloat(priceTF.getText());
                            if(!ss.userExists(customerID)){
                               JOptionPane.showMessageDialog(null, "The customer ID you have entered does not exist in the database.", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else if(!ss.userExists(employeeID)){
                                JOptionPane.showMessageDialog(null, "The employee ID you have entered does not exist in the database.", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else if(!ss.packageExists(trackNum)){
                                JOptionPane.showMessageDialog(null, "The package with the tracking number you are trying to deliver "
                            + "does not exist in the database. Aborting transaction.", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                            else if(price < 0.0f){
                                JOptionPane.showMessageDialog(null, "Price cannot be negative.", "Warning", JOptionPane.WARNING_MESSAGE);
                            }
                        }catch(NumberFormatException er){
                            logger.log(Level.WARNING, "Price for package NOT float");
                            JOptionPane.showMessageDialog(null, "Price must be a float value", "Warning", JOptionPane.WARNING_MESSAGE);
                            
                        }
                    }
                });
                
                // lambda expression for actionlistener of return button
                backButton.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
            else if(showAllTRButton.isSelected()){
                logger.log(Level.INFO, "Inputting info for showing all transactions");
                // Hiding menu frame
                frame1.setVisible(false);
                // creating new frame called SHOW ALL PACKAGES
                JFrame frame2 = new JFrame("Show all Transactions.");
                frame2.setPreferredSize(new Dimension(1000,1000));
                frame2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame2.setLayout(new BorderLayout());
                
                String[] columnNames = {"CUSTOMER ID",
                                        "EMPLOYEE ID",
                                        "TRACKING #",
                                        "SHIPPING DATE",
                                        "DELIVERY DATE",
                                        "PRICE"};
                String[][] tList = new String[ss.transactions.size()][6];
                
                for(Transaction t: ss.transactions){
                    String stringme = ss.transactions.get(ss.transactions.indexOf(t)).stringMe();
                    String[] split = stringme.split("~");
                    tList[ss.transactions.indexOf(t)][0] = split[0];
                    tList[ss.transactions.indexOf(t)][1] = split[1];
                    tList[ss.transactions.indexOf(t)][2] = split[2];
                    tList[ss.transactions.indexOf(t)][3] = split[3];
                    tList[ss.transactions.indexOf(t)][4] = split[4];
                    tList[ss.transactions.indexOf(t)][5] = split[5];
                }
                // adding panel for return button
                JTable table = new JTable(tList,columnNames);
                JScrollPane scrollPane = new JScrollPane(table);
                
                frame2.add(scrollPane, BorderLayout.CENTER);
                JPanel pan = new JPanel();
                pan.setLayout(new FlowLayout(FlowLayout.LEFT));
                JButton back = new JButton("Back to Menu");
                pan.add(back);
                // adding panel to frame2 Show all packages.
                frame2.add(pan,BorderLayout.SOUTH);
                frame2.setVisible(true); frame2.pack();
                // lambda expression for actionlistener of return button
                back.addActionListener((ActionEvent e1) -> {
                    frame2.setVisible(false);
                    frame1.setVisible(true);
                });
            }
        });
    }
    /**
     * @param args the command line arguments
     * main method just calls GUI method as well as initializes the logging method
     */
    public static void main(String[] args) throws BadInputException{
        // TODO code application logic here
        initFh();
        showGui();
        
        
    }
}
