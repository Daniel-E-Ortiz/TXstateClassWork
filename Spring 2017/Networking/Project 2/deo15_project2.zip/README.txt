-- to run:

./agent.exe <ServerIP> <PORT> <"ACTION">

-- to compile (if necessary)

g++ -std=c++11 -o server.exe server.cpp
gcc -o agent.exe agent.c





Yes it needs "" for some reason...