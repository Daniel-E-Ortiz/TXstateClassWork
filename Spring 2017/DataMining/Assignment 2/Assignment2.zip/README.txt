To use the file, run the .exe file named "Assignment_2_KMeans.exe" and press enter whenever prompted. Do not delete any files within the Zip folder as it may or may not break my program. 

This program was created using C# using Visual Studio 2015.
This is also the first time I have created a program in C# and I used this assignment as a way for me to learn so please mind my messy code. :-)

Thank you for reading!

- Daniel Ortiz