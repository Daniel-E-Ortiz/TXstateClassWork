﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data;
namespace Assignment_2_KMeans
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Beginning of K-Means!");
            Console.WriteLine("From Input1.txt");
            string path = "input1.txt";
            int k = 2;
            double[][] rawData = getData(path,k);
            Console.WriteLine("Press Enter to continue...");
            Console.ReadKey();
            Console.WriteLine("\n *=-=*=- Raw Data -=*=-=*\n");
            showData(rawData);
            Console.WriteLine("-1 is set as they do not belong to any cluster.");
            Console.WriteLine("Setting K to " + k);
            Console.WriteLine("Arbitrarily splitting raw data into " + k + " clusters.");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            double[][] centroidA = new double[1][];
            double[][] centroidB = new double[1][];
            double[][] centroidC = new double[1][];
            double[][] centroidD = new double[1][];
            //~~~~~~~~~~~~~~~~~~~~~~~    X coordinate   Y coordinate
            centroidA[0] = new double[] { rawData[0][0], rawData[0][1] };
            centroidB[0] = new double[] { rawData[rawData.Length / 2 - 1][0], rawData[rawData.Length / 2 - 1][1] };
            centroidC[0] = new double[] { rawData[rawData.Length / 2][0], rawData[rawData.Length / 2][1] };
            centroidD[0] = new double[] { rawData[rawData.Length - 1][0], rawData[rawData.Length - 1][1] };
            bool movement;
            do
            {
                movement = clusterMe(rawData, k, centroidA, centroidB, centroidC, centroidD);   
            } while (movement == true);
            Console.WriteLine("\n *=-=*=- Updated Data -=*=-=*\n");
            showData(rawData);
            string outPath = "output1.txt";
            outputData(rawData,outPath);
            Console.WriteLine("Output to Output1.txt");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~input2.txt~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Console.WriteLine("From Input2.txt");
            path = "input2.txt";
            k = 2;
            double[][] rawData2 = getData(path, k);
            Console.WriteLine("Press Enter to continue...");
            Console.ReadKey();
            Console.WriteLine("\n *=-=*=- Raw Data -=*=-=*\n");
            showData(rawData2);
            Console.WriteLine("-1 is set as they do not belong to any cluster.");
            Console.WriteLine("Setting K to " + k);
            Console.WriteLine("Arbitrarily splitting raw data into " + k + " clusters.");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            double[][] centroidA2 = new double[1][];
            double[][] centroidB2 = new double[1][];
            double[][] centroidC2 = new double[1][];
            double[][] centroidD2 = new double[1][];
            //~~~~~~~~~~~~~~~~~~~~~~~    X coordinate   Y coordinate
            centroidA2[0] = new double[] { rawData2[0][0], rawData2[0][1] };
            centroidB2[0] = new double[] { rawData2[rawData2.Length / 2 - 1][0], rawData2[rawData2.Length / 2 - 1][1] };
            centroidC2[0] = new double[] { rawData2[rawData2.Length / 2][0], rawData2[rawData2.Length / 2][1] };
            centroidD2[0] = new double[] { rawData2[rawData2.Length - 1][0], rawData2[rawData2.Length - 1][1] };
            do
            {
                movement = clusterMe(rawData2, k, centroidA2, centroidB2, centroidC2, centroidD2);
            } while (movement == true);
            Console.WriteLine("\n *=-=*=- Updated Data -=*=-=*\n");
            showData(rawData2);
            outPath = "output2.txt";
            outputData(rawData2, outPath);
            Console.WriteLine("Output to Output2.txt");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~input3.txt~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Console.WriteLine("From Input3.txt");
            path = "input3.txt";
            k = 3;
            double[][] rawData3 = getData(path, k);
            Console.WriteLine("Press Enter to continue...");
            Console.ReadKey();
            Console.WriteLine("\n *=-=*=- Raw Data -=*=-=*\n");
            showData(rawData3);
            Console.WriteLine("-1 is set as they do not belong to any cluster.");
            Console.WriteLine("Setting K to " + k);
            Console.WriteLine("Arbitrarily splitting raw data into " + k + " clusters.");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            double[][] centroidA3 = new double[1][];
            double[][] centroidB3 = new double[1][];
            double[][] centroidC3 = new double[1][];
            double[][] centroidD3 = new double[1][];
            //~~~~~~~~~~~~~~~~~~~~~~~    X coordinate   Y coordinate
            centroidA3[0] = new double[] { rawData3[0][0], rawData3[0][1] };
            centroidB3[0] = new double[] { rawData3[rawData3.Length / 2 - 1][0], rawData3[rawData3.Length / 2 - 1][1] };
            centroidC3[0] = new double[] { rawData3[rawData3.Length / 2][0], rawData3[rawData3.Length / 2][1] };
            centroidD3[0] = new double[] { rawData3[rawData3.Length - 1][0], rawData3[rawData3.Length - 1][1] };
            do
            {
                movement = clusterMe(rawData3, k, centroidA3, centroidB3, centroidC3, centroidD3);
            } while (movement == true);
            Console.WriteLine("\n *=-=*=- Updated Data -=*=-=*\n");
            showData(rawData3);
            outPath = "output3.txt";
            outputData(rawData3, outPath);
            Console.WriteLine("Output to Output3.txt");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~input4.txt~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            Console.WriteLine("From Input4.txt");
            path = "input4.txt";
            k = 4;
            double[][] rawData4 = getData(path, k);
            Console.WriteLine("Press Enter to continue...");
            Console.ReadKey();
            Console.WriteLine("\n *=-=*=- Raw Data -=*=-=*\n");
            showData(rawData4);
            Console.WriteLine("-1 is set as they do not belong to any cluster.");
            Console.WriteLine("Setting K to " + k);
            Console.WriteLine("Arbitrarily splitting raw data into " + k + " clusters.");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
            double[][] centroidA4 = new double[1][];
            double[][] centroidB4 = new double[1][];
            double[][] centroidC4 = new double[1][];
            double[][] centroidD4 = new double[1][];
            //~~~~~~~~~~~~~~~~~~~~~~~    X coordinate   Y coordinate
            centroidA4[0] = new double[] { rawData4[0][0], rawData4[0][1] };
            centroidB4[0] = new double[] { rawData4[rawData4.Length / 2 - 1][0], rawData4[rawData4.Length / 2 - 1][1] };
            centroidC4[0] = new double[] { rawData4[rawData4.Length / 2][0], rawData4[rawData4.Length / 2][1] };
            centroidD4[0] = new double[] { rawData4[rawData4.Length - 1][0], rawData4[rawData4.Length - 1][1] };
            do
            {
                movement = clusterMe(rawData4, k, centroidA4, centroidB4, centroidC4, centroidD4);
            } while (movement == true);
            Console.WriteLine("\n *=-=*=- Updated Data -=*=-=*\n");
            showData(rawData4);
            outPath = "output4.txt";
            outputData(rawData4, outPath);
            Console.WriteLine("Output to Output4.txt");
            Console.WriteLine("\nPress Enter to continue...");
            Console.ReadKey();
        }
        static void outputData(double[][] data, string path)
        {
           using (System.IO.StreamWriter file =
           new System.IO.StreamWriter(@path))
            {
                for (int i = 0; i < data.Length; i++)
                {
                    file.WriteLine(data[i][0] + "\t" + data[i][1] + "\t" + data[i][2]);
                }
            }
        }
        static void showData(double[][] data)
        {
            Console.WriteLine("#\tX\tY\n-------------------");
            for (int i = 0; i < data.Length; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write(data[i][j] + "\t");
                }
                Console.Write('\n');
            }
            Console.WriteLine("-------------------");
        }
        static double[][] getData(string path, int k)
        {
            string[] lines = File.ReadAllLines(path);
            double[][] rawData = new double[lines.Length][];
            int i = 0, j = 0;
            foreach (string line in lines)
            {
                string[] rawSplit = line.Split('\t');
                rawData[i++] = new double[] { Convert.ToDouble(rawSplit[j++]), Convert.ToDouble(rawSplit[j]), -1};
                j = 0;
            }
            
            return rawData;
        }
        static bool clusterMe(double[][] rawData, int k, double[][]centroidA,double[][]centroidB,double[][]centroidC,double[][]centroidD)
        {
            bool movement = false;
            double x = 0.0, y = 0.0, distanceA = 0.0, distanceB = 0.0, distanceC = 0.0, distanceD = 0.0;
            double centroidA_X_total = 0.0, centroidA_Y_total = 0.0,
                   centroidB_X_total = 0.0, centroidB_Y_total = 0.0,
                   centroidC_X_total = 0.0, centroidC_Y_total = 0.0,
                   centroidD_X_total = 0.0, centroidD_Y_total = 0.0;
            int clusterA_count = 0,
                clusterB_count = 0,
                clusterC_count = 0,
                clusterD_count = 0;
            for (int i = 0; i < rawData.Length; i++)
            {
                if (k == 2)
                {
                    // "Euclidian" distance = Sqrt(((x1-x2)^2) + ((y1-y2)^2)));
                    x = rawData[i][0] - centroidA[0][0];
                    y = rawData[i][1] - centroidA[0][1];
                    distanceA = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidB[0][0];
                    y = rawData[i][1] - centroidB[0][1];
                    distanceB = Math.Sqrt((x * x) + (y * y));
                    if (distanceA <= distanceB)
                    {
                        if (rawData[i][2] != 1)
                        {
                            movement = true;
                            rawData[i][2] = 1;
                        }
                        
                    }
                    else
                    {
                        if (rawData[i][2] != 2)
                        {
                            movement = true;
                            rawData[i][2] = 2;
                        }
                    }
                }
                if (k == 3)
                {
                    x = rawData[i][0] - centroidA[0][0];
                    y = rawData[i][1] - centroidA[0][1];
                    distanceA = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidB[0][0];
                    y = rawData[i][1] - centroidB[0][1];
                    distanceB = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidC[0][0];
                    y = rawData[i][1] - centroidC[0][1];
                    distanceC = Math.Sqrt((x * x) + (y * y));
                    if (distanceA <= distanceB && distanceA <= distanceC)
                    {
                        if (rawData[i][2] != 1)
                        {
                            movement = true;
                            rawData[i][2] = 1;
                        }
                    }
                    else if (distanceB <= distanceC)
                    {
                        if (rawData[i][2] != 2)
                        {
                            movement = true;
                            rawData[i][2] = 2;
                        }
                    }
                    else
                    {
                        if (rawData[i][2] != 3)
                        {
                            movement = true;
                            rawData[i][2] = 3;
                        }
                    }
                }
                if (k == 4)
                {
                    x = rawData[i][0] - centroidA[0][0];
                    y = rawData[i][1] - centroidA[0][1];
                    distanceA = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidB[0][0];
                    y = rawData[i][1] - centroidB[0][1];
                    distanceB = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidC[0][0];
                    y = rawData[i][1] - centroidC[0][1];
                    distanceC = Math.Sqrt((x * x) + (y * y));
                    x = rawData[i][0] - centroidD[0][0];
                    y = rawData[i][1] - centroidD[0][1];
                    distanceD = Math.Sqrt((x * x) + (y * y));
                    if (distanceA <= distanceB && distanceA <= distanceC && distanceA <= distanceD)
                    {
                        if (rawData[i][2] != 1)
                        {
                            movement = true;
                            rawData[i][2] = 1;
                        }
                    }
                    else if (distanceB <= distanceC && distanceB <= distanceD)
                    {
                        if (rawData[i][2] != 2)
                        {
                            movement = true;
                            rawData[i][2] = 2;
                        }
                    }
                    else if (distanceC <= distanceD)
                    {
                        if (rawData[i][2] != 3)
                        {
                            movement = true;
                            rawData[i][2] = 3;
                        }
                    }
                    else
                    {
                        if (rawData[i][2] != 4)
                        {
                            movement = true;
                            rawData[i][2] = 4;
                        }
                    }
                }
            }
            for (int n = 0; n < rawData.Length; n++)
            {
                if (rawData[n][2] == 1)
                {
                    centroidA_X_total += rawData[n][0];
                    centroidA_Y_total += rawData[n][1];
                    clusterA_count++;
                }
                if (rawData[n][2] == 2)
                {
                    centroidB_X_total += rawData[n][0];
                    centroidB_Y_total += rawData[n][1];
                    clusterB_count++;
                }
                if (rawData[n][2] == 3)
                {
                    centroidC_X_total += rawData[n][0];
                    centroidC_Y_total += rawData[n][1];
                    clusterC_count++;
                }
                if (rawData[n][2] == 4)
                {
                    centroidD_X_total += rawData[n][0];
                    centroidD_Y_total += rawData[n][1];
                    clusterD_count++;
                }
            }
            centroidA[0][0] = centroidA_X_total / clusterA_count;
            centroidA[0][1] = centroidA_Y_total / clusterA_count;
            centroidB[0][0] = centroidB_X_total / clusterB_count;
            centroidB[0][1] = centroidB_Y_total / clusterB_count;
            centroidC[0][0] = centroidC_X_total / clusterC_count;
            centroidC[0][1] = centroidC_Y_total / clusterC_count;
            centroidD[0][0] = centroidD_X_total / clusterD_count;
            centroidD[0][1] = centroidD_Y_total / clusterD_count;
            return movement;
        }
    }
}

